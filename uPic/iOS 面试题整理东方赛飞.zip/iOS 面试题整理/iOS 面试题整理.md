# iOS 面试题整理

# 一、UI类：

### 1、UIView 和 CALayer 是什么关系?

- UIView 显示在屏幕上归功于 CALayer，通过调用 drawRect 方法来渲染自身的内容，调节 CALayer 属性可以调整 UIView 的外观，
- UIView 继承自 UIResponder，比起 CALayer 可以响应用户事件，Xcode6 之后可以方便的通过视图调试功能查看图层之间的关系
- UIView 是 iOS 系统中界面元素的基础，所有的界面元素都继承自它。它内部是由 Core Animation 来实现的，它真正的绘图部分，是由一个叫 CALayer(Core Animation Layer) 的类来管理。UIView 本身，更像是一个 CALayer 的管理器，访问它的跟绘图和坐标有关的属性，如 frame，bounds 等，实际上内部都是访问它所在 CALayer 的相关属性
- UIView 有个 layer 属性，可以返回它的主 CALayer 实例，UIView 有一个 layerClass 方法，返回主 layer 所使用的类，UIView 的子类，可以通过重载这个方法，来让 UIView 使用不同的 CALayer 来显示，如：


```Objective-C
- (class) layerClass {
    
    return ([CAEAGLLayer class]);
}
```


- UIView 的 CALayer 类似 UIView 的子 View 树形结构，也可以向它的 layer 上添加子 layer，来完成某些特殊的显示。例如下面的代码会在目标 View 上敷上一层黑色的透明薄膜。

```Objective-C
grayCover = [[CALayer alloc]init];
grayCover.backgroudColor = [[UIColor blackColor]colorWithAlphaComponent:0.2].CGColor;
[self.layer addSubLayer:grayCover];
```




### 2、loadView 的作用？

- loadView 用来自定义 view，只要实现了这个方法，其他通过 xib 或 storyboard 创建的 view 都不会被加载
- 看懂控制器 view 创建的这个图就行

![](image/image.png "")

### 3、IBOutlet 连出来的视图属性为什么可以被设置成 weak?

- 因为父控件的 subViews 数组已经对它有一个强引用

### 4、沙盒目录结构是怎样的？各自用于那些场景？

- Application：存放程序源文件，上架前经过数字签名，上架后不可修改
- Documents：常用目录，iCloud 备份目录，存放数据
- Library
	- Caches：存放体积大又不需要备份的数据
	- Preference：设置目录，iCloud 会备份设置信息
- tmp：存放临时文件，不会被备份，而且这个文件下的数据有可能随时被清除的可能

### 5、pushViewController 和 presentViewController 有什么区别

- 两者都是在多个试图控制器间跳转的函数
- presentViewController 提供的是一个模态视图控制器 (modal)
- pushViewController 提供一个栈控制器数组，push/pop

### 6、请简述 UITableView 的复用机制

- 每次创建 cell 的时候通过 dequeueReusableCellWithIdentifier: 方法创建 cell，它先到缓存池中找指定标识的 cell，如果没有就直接返回 nil
- 如果没有找到指定标识的 cell，那么会通过 initWithStyle:reuseIdentifier: 创建一个 cell
- 当 cell 离开界面就会被放到缓存池中，以供下次复用

### 7、使用 drawRect 有什么影响？

- drawRect 方法依赖 Core Graphics 框架来进行自定义的绘制
- 缺点：它处理 touch 事件时每次按钮被点击后，都会用 setNeddsDisplay 进行强制重绘；而且不止一次，每次单点事件触发两次执行。这样的话从性能的角度来说，对 CPU 和内存来说都是欠佳的。特别是如果在我们的界面上有多个这样的 UIButton 实例，那就会很糟糕了

面试题持续整理更新中，如果你正在面试或者想一起进阶，不妨添加一下交流群 1012951431 一起交流。

- 这个方法的调用机制也是非常特别. 当你调用 setNeedsDisplay 方法时, UIKit 将会把当前图层标记为 dirty, 但还是会显示原来的内容, 直到下一次的视图渲染周期, 才会将标记为 dirty 的图层重新建立 Core Graphics 上下文, 然后将内存中的数据恢复出来, 再使用 CGContextRef 进行绘制

### 8、描述下 SDWebImage 里面给 UIImageView 加载图片的逻辑

- SDWebImage 中为 UIImageView 提供了一个分类 UIImageView+WebCache.h, 这个分类中有一个最常用的接口 sd_setImageWithURL:placeholderImage:，会在真实图片出现前会先显示占位图片，当真实图片被加载出来后在替换占位图片
- 加载图片的过程大致如下：
	- 首先会在 SDWebImageCache 中寻找图片是否有对应的缓存, 它会以 url 作为数据的索引先在内存中寻找是否有对应的缓存
	- 如果缓存未找到就会利用通过 MD5 处理过的 key 来继续在磁盘中查询对应的数据, 如果找到了, 就会把磁盘中的数据加载到内存中，并将图片显示出来
	- 如果在内存和磁盘缓存中都没有找到，就会向远程服务器发送请求，开始下载图片
	- 下载后的图片会加入缓存中，并写入磁盘中
	- 整个获取图片的过程都是在子线程中执行，获取到图片后回到主线程将图片显示出来

### 9、VC生命周期

考察viewDidLoad、viewWillAppear、ViewDidAppear等方法的执行顺序。 假设现在有一个 AViewController(简称 Avc) 和 BViewController (简称 Bvc)，通过 navigationController 的push 实现 Avc 到 Bvc 的跳转，调用顺序如下： 

1、A viewDidLoad  

2、A viewWillAppear 

 3、A viewDidAppear  

4、B viewDidLoad  

5、A viewWillDisappear  

6、B viewWillAppear 

 7、A viewDidDisappear  

8、B viewDidAppear 

如果再从 Bvc 跳回 Avc，调用顺序如下： 

1、B viewWillDisappear  

2、A viewWillAppear  

3、B viewDidDisappear  

4、A viewDidAppear

#### 10、iOS 为什么必须在主线程中操作UI

- UIKit不是线程安全的(多个线程访问修改,可能一个线程已经释放了,另一个线程会访问,以及资源抢夺问题等)
- 主线程上默认是开始 runloop 的,子线程没有 runloop 也无法监听一些事件,手势刷新UI等操作
- 在子线程更新UI可能会无效,也可能会崩溃

#### 11、如何处理UITableVier 中Cell 动态计算高度的问题，都有哪些方案

- 你的Cell要使用AutoLayout来布局约束这是必须的；设置tableview的estimatedRowHeight为一个非零值，这个属性是设置一个预估的高度值，不用太精确。 设置tableview的rowHeight属性为UITableViewAutomaticDimension
- 第三方 UITableView+FDTemplateLayoutCell(计算布局高度缓存的)
- 手动计算每个控件的 高度并相加,最后缓存高度

### 12、什么是离屏渲染？

如果要在显示屏上显示内容，我们至少需要一块与屏幕像素数据量一样大的frame buffer，作为像素数据存储区域，而这也是GPU存储渲染结果的地方。如果有时因为面临一些限制，无法把渲染结果直接写入frame buffer，而是先暂存在另外的内存区域，之后再写入frame buffer，那么这个过程被称之为离屏渲染。 

![](https://camo.githubusercontent.com/966780ee85124c880942dde41ed8f0e485e47e0a00d31ad8c93e14cc15a01565/68747470733a2f2f75706c6f61642d696d616765732e6a69616e7368752e696f2f75706c6f61645f696d616765732f32323837373939322d663538653861386463373437326564362e706e673f696d6167654d6f6772322f6175746f2d6f7269656e742f7374726970253743696d61676556696577322f322f772f31323430 "")

- 在 OpenGL 中，GPU 屏幕渲染有以下两种方式： 一、On-Screen Rendering 即当前屏幕渲染，在用于显示的屏幕缓冲区中进行，不需要额外创建新的缓存，也不需要开启新的上下文，所以性能较好，但是受到缓存大小限制等因素，一些复杂的操作无法完成。 二、Off-Screen Rendering 即离屏渲染，指的是在GPU的当前屏幕缓冲区外开辟新的缓冲区进行操作。 相比于当前屏幕渲染，离屏渲染的代价是很高的，主要体现在如下两个方面： 1、创建新的缓冲区 2、上下文切换。离屏渲染的整个过程，需要多次切换上下文环境：先从当前屏幕切换到离屏，等待离屏渲染结束后，将离屏缓冲区的渲染结果显示到到屏幕上，这又需要将上下文环境从离屏切换到当前屏幕。
- CPU 渲染和离屏渲染的区别 由于GPU的浮点运算能力比CPU强，CPU渲染的效率可能不如离屏渲染。但如果仅仅是实现一个简单的效果，直接使用 CPU 渲染的效率又可能比离屏渲染好，毕竟普通的离屏渲染要涉及到缓冲区创建和上下文切换等耗时操作。对一些简单的绘制过程来说，这个过程有可能用CoreGraphics，全部用CPU来完成反而会比GPU做得更好。一个常见的 CPU 渲染的例子是：重写 drawRect 方法，并且使用任何 Core Graphics 的技术进行了绘制操作，就涉及到了 CPU 渲染。整个渲染过程由 CPU 在 App 内同步地完成，渲染得到的bitmap最后再交由GPU用于显示。总之，具体使用 CPU 渲染还是使用 GPU 离屏渲染更多的时候需要进行性能上的具体比较才可以。
- iOS 9.0 之前UIimageView跟UIButton设置圆角都会触发离屏渲染。 iOS 9.0 之后UIButton设置圆角会触发离屏渲染，而UIImageView里png图片设置圆角不会触发离屏渲染了，如果设置其他阴影效果之类的还是会触发离屏渲染的。

### 13、造成离屏渲染原因

- shouldRasterize（光栅化）。
- masks（遮罩）。
- shadows（阴影）。
- edge antialiasing（抗锯齿）。
- group opacity（不透明）
- clearColor、alpha等操作。

### 14、离屏渲染的解决方案

- clearColor可以通过直接设置颜色来解决。
- alpha为0时候用hidden替换。
- 圆角、边框解决方案：1、UIBezierPath 2、使用Core Graphics为UIView加圆角 3、直接处理图片为圆角 4、后台处理圆角
- 阴影解决方案：shadowPath替换。
- 尝试开启CALayer.shouldRasterize。
- 对于不透明的View，设置opaque为YES，这样在绘制该View时，就不需要考虑被View覆盖的其他内容（尽量设置Cell的view为opaque，避免GPU对Cell下面的内容也进行绘制）

### 15、图片子线程预加载及预处理

- 图片子线程异步下载。
- 图片子线程处理。比如对于圆角图片，可以让后台传圆角图片，也可以在子线程生成圆角图片，也可以用UIBezierPath生成圆角；在子线程缩放图片然后加载到图片控件上。
- 图片按需下载。只下载显示的cell的图片。

### 16、Bounds 和 Frame 的区别?

Bounds：一般是相对于自身来说的，是控件的内部尺寸。如果你修改了 Bounds，那么子控件的相对位置也会发生改变。

Frame ：是相对于父控件来说的，是控件的外部尺寸。

### 17、setNeedsDisplay 和 layoutIfNeeded 两者是什么关系？

UIView的setNeedsDisplay和setNeedsLayout两个方法都是异步执行的。而setNeedsDisplay会自动调用drawRect方法，这样可以拿到UIGraphicsGetCurrentContext进行绘制；而setNeedsLayout会默认调用layoutSubViews，给当前的视图做了标记；layoutIfNeeded 查找是否有标记，如果有标记及立刻刷新。  
只有setNeedsLayout和layoutIfNeeded这二者合起来使用，才会起到立刻刷新的效果。

### 18、谈谈对 UIResponder 的理解

UIResponder 类是专门用来响应用户的操作处理各种事件的，包括触摸事件 (Touch Events)、运动事件 (Motion Events)、远程控制事件 (Remote Control Events)。我们知道 UIApplication、UIView、UIViewController 这几个类是直接继承自 UIResponder，所以这些类都可以响应事件。当然我们自定义的继承自 UIView 的 View 以及自定义的继承自 UIViewController 的控制器都可以响应事件。

### 19、Main函数之前做了什么？ 

1. 动态库链接库
2. ImageLoader加载可执行文件，里面是被编译过的符号、代码等
3. runtime与+load

### 20、APP的启动过程，从main开始

1.main 函数

2.UIApplicationMain

*创建UIApplication对象    

*创建UIApplication的delegate对象

3.如果有storyboard，根据info.plist获得Main.storyboard的文件名，加载Main.storyboard；如果没有storyboard，AppDelegate对象开始处理（监听）系统事件，程序启动完毕的时候，在application:didFinishLaunchingWithOptions:中

*创建UIWindow

*创建和设置UIWindow的rootViewController 

*显示窗口

#### 21、手机适配方案

1. 使用宏,针对不同的设备抽取导航,状态栏,以及 tabbar 高度信息
2. 宽高等比适配(X 的特殊处理)
3. 图片美工需要提供@2x,@3x进行适配
4. 字体根据屏幕大小适配
5. 权限针对不同系统进行适配
6. api 适配

# 二、多线程：

### 1、iOS的多线程方案有哪几种？

![](https://upload-images.jianshu.io/upload_images/1696952-514db7679a605c70.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp "")

### 2、GCD 的队列类型?

GCD的队列可以分为2大类型

- 并发队列（`Concurrent Dispatch Queue`）  
	可以让多个任务并发（同时）执行（自动开启多个线程同时执行任务）  
	并发功能只有在异步（`dispatch_async`）函数下才有效
- 串行队列（`Serial Dispatch Queue`）  
	让任务一个接着一个地执行（一个任务执行完毕后，再执行下一个任务）,按照FIFO顺序执行.

### 3、dispatch_group_t (组调度)的使用?

```Objective-C
dispatch_group_t group = dispatch_group_create();
dispatch_group_async(group, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    //请求1
});
dispatch_group_async(group, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    //请求2
});
dispatch_group_async(group, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    //请求3
});
dispatch_group_notify(group, dispatch_get_main_queue(), ^{
    //界面刷新
    NSLog(@"任务均完成，刷新界面");
});

```


### 4、dispatch_semaphore (信号量)如何使用?

- 用于控制最大并发数
- 可以防止资源抢夺

与他相关的共有三个函数，分别是

```Objective-C
dispatch_semaphore_create，  // 创建最大并发数

dispatch_semaphore_wait。    // -1 开始执行 (0则等待)

dispatch_semaphore_signal，  // +1 
```


### 5、NSOperation如何实现操作依赖?

```Objective-C
NSOperationQueue *queue=[[NSOperationQueue alloc] init];
//创建操作
NSBlockOperation *operation1=[NSBlockOperation blockOperationWithBlock:^(){
    NSLog(@"执行第1次操作，线程：%@",[NSThread currentThread]);
}];
NSBlockOperation *operation2=[NSBlockOperation blockOperationWithBlock:^(){
    NSLog(@"执行第2次操作，线程：%@",[NSThread currentThread]);
}];
NSBlockOperation *operation3=[NSBlockOperation blockOperationWithBlock:^(){
    NSLog(@"执行第3次操作，线程：%@",[NSThread currentThread]);
}];
//添加依赖
[operation1 addDependency:operation2];
[operation2 addDependency:operation3];
//将操作添加到队列中去
[queue addOperation:operation1];
[queue addOperation:operation2];
[queue addOperation:operation3];
```


### 6、是否可以把比较耗时的操作放在 NSNotification中?

- 如果在异步线程发的通知，那么可以执行比较耗时的操作;
- 如果在主线程发的通知，那么就不可以执行比较耗时的操作

### 7、说几个你在工作中使用到的线程安全的例子?

UIKit(必须在主线程)
FMDBDataBaseQueue(串行队列)
等等..

### 8、dispatch_barrier_(a)sync使用?
一个dispatch barrier 允许在一个并发队列中创建一个同步点。当在并发队列中遇到一个barrier, 他会延迟执行barrier的block,等待所有在barrier之前提交的blocks执行结束。 这时，barrier block自己开始执行。 之后， 队列继续正常的执行操作。

### 9、在项目什么时候选择使用 GCD，什么时候选 择 NSOperation?

- 项目中使用 NSOperation 的优点是 NSOperation 是对线程的高度抽象，在项目中使 用它，会使项目的程序结构更好，子类化 NSOperation 的设计思路，是具有面向对 象的优点(复用、封装)，使得实现是多线程支持，而接口简单，建议在复杂项目中 使用。
- 项目中使用 GCD 的优点是 GCD 本身非常简单、易用，对于不复杂的多线程操 作，会节省代码量，而 Block 参数的使用，会是代码更为易读，建议在简单项目中 使用。

### 10、说一下 OperationQueue 和 GCD 的区别，以及各自的优势

1. GCD是纯C语⾔言的API，NSOperationQueue是基于GCD的OC版本封装
2. GCD只⽀支持FIFO的队列列，NSOperationQueue可以很⽅方便便地调整执⾏行行顺 序、设 置最⼤大并发数量量
3. NSOperationQueue可以在轻松在Operation间设置依赖关系，⽽而GCD 需要写很 多的代码才能实现
4. NSOperationQueue⽀支持KVO，可以监测operation是否正在执⾏行行 (isExecuted)、 是否结束(isFinished)，是否取消(isCanceld)
5. GCD的执⾏行行速度⽐比NSOperationQueue快 任务之间不不太互相依赖:GCD 任务之间 有依赖\或者要监听任务的执⾏行行情况:NSOperationQueue

### 11、GCD如何取消线程?

`dispatch_block_cancel`类似NSOperation一样，可以取消还未执行的线程。但是没办法做到取消一个正在执行的线程。

```Objective-C
dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
dispatch_block_t block1 = dispatch_block_create(0, ^{
    NSLog(@"block1");
});
dispatch_block_t block2 = dispatch_block_create(0, ^{
    NSLog(@"block2");
});
    
dispatch_block_t block3 = dispatch_block_create(0, ^{
    NSLog(@"block3");
});
    
dispatch_async(queue, block1);
dispatch_async(queue, block2);
dispatch_async(queue, block3);
dispatch_block_cancel(block3); // 取消 block3
```


使用`临时变量+return` 方式取消 正在执行的Block

```Objective-C
__block BOOL gcdFlag= NO; // 临时变量
dispatch_async(dispatch_get_global_queue(0, 0), ^{
    for (long i=0; i<1000; i++) {
        NSLog(@"正在执行第i次:%ld",i);
        sleep(1);
        if (gcdFlag==YES) { // 判断并终止
            NSLog(@"终止");
            return ;
        }
    };
});
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                   NSLog(@"我要停止啦");
                   gcdFlag = YES;
               });
```


### 12、NSOperation取消线程方式?

.通过 cancel 取消未执行的单个操作

```Objective-C
NSOperationQueue *queue1 = [[NSOperationQueue alloc]init];
NSBlockOperation *block1 = [NSBlockOperation blockOperationWithBlock:^{
    NSLog(@"block11");
}];
NSBlockOperation *block2 = [NSBlockOperation blockOperationWithBlock:^{
    NSLog(@"block22");
}];
NSBlockOperation *block3 = [NSBlockOperation blockOperationWithBlock:^{
    NSLog(@"block33");
}];
[block3 cancel];
[queue1 addOperations:@[block1,block2,block3] waitUntilFinished:YES];
```


移除队列里面所有的操作，但正在执行的操作无法移除

```Objective-C
[queue1 cancelAllOperations];
```


挂起队列，使队列任务不再执行，但正在执行的操作无法挂起

`queue1.suspended = YES;`

我们可以自定义NSOperation，实现取消正在执行的操作。其实就是拦截main方法。

```Objective-C
 main方法：
 1、任何操作在执行时，首先会调用start方法，start方法会更新操作的状态（过滤操作,如过滤掉处于“取消”状态的操作）。
 2、经start方法过滤后，只有正常可执行的操作，就会调用main方法。
 3、重写操作的入口方法(main)，就可以在这个方法里面指定操作执行的任务。
 4、main方法默认是在子线程异步执行的。
```


### 13、什么是线程安全?

- 1块资源可能会被多个线程共享，也就是多个线程可能会访问同一块资源
- 比如多个线程访问同一个对象、同一个变量、同一个文件
- 当多个线程访问同一块资源时，很容易引发数据错乱和数据安全问题

### 14、线程安全的处理手段有哪些？

- 加锁
- 同步执行

### 15、如何理解GCD死锁?

- 所谓死锁.通常是指2个操作相互等待对方完成,造成死循环,于是2个操作都无法进行,就产生了死锁;

### 16、自旋锁和互斥锁的是什么?

- 自旋锁会忙等: 所谓忙等，即在访问被锁资源时，调用者线程不会休眠，而是不停循环在那里，直到被锁资源释放锁。
- 互斥锁会休眠: 所谓休眠，即在访问被锁资源时，调用者线程会休眠，此时cpu可以调度其他线程工作。直到被锁资源释放锁。此时会唤醒休眠线程。

### 17、OC你了解的锁有哪些？

- os_unfair_lock ios10 开始
- OSSpanLock ios10 废弃
- dispatch_semaphore 建议使用,性能也比较好
- dispatch_mutex
- dispatch_queue 串行
- NSLock 对 mutex 封装
- @synchronized 性能最差

## 18、什么情况使用自旋锁比较划算？

- 预计线程等待锁的时间很短
- 加锁的代码（临界区）经常被调用，但竞争情况很少发生
- CPU资源不紧张
- 多核处理器

## 19、什么情况使用互斥锁比较划算？

- 预计线程等待锁的时间较长
- 单核处理器
- 临界区有IO操作
- 临界区代码复杂或者循环量大
- 临界区竞争非常激烈

# 三、三方库：

## 1、RxSwift基本概念与使用

RxSwift 属于函数响应式编程。它是通过构建函数操作数据序列，然后对这些序列做出响应的编程方式。它结合了函数式编程以及响应式编程。

#### 函数式编程

函数式编程需要我们将函数作为参数传递，或者作为返回值返回。我们可以通过组合不同的函数来得到想要的结果。

#### 响应式编程

响应式编程是使用异步数据流进行编程。任何事物都可以是一个数据流，如用户输入、点击事件、定时器、网络请求等，监听数据流并相应的作出响应。

## 2、RxSwift 核心

- [Observable](https://beeth0ven.github.io/RxSwift-Chinese-Documentation/rxswift_core/observable.html) - 产生事件
- [Observer](https://beeth0ven.github.io/RxSwift-Chinese-Documentation/rxswift_core/observer.html) - 响应事件
- [Operator](https://beeth0ven.github.io/RxSwift-Chinese-Documentation/rxswift_core/operator.html) - 创建变化组合事件
- [Disposable](https://beeth0ven.github.io/RxSwift-Chinese-Documentation/rxswift_core/disposable.html) - 管理绑定（订阅）的生命周期
- [Schedulers](https://beeth0ven.github.io/RxSwift-Chinese-Documentation/rxswift_core/schedulers.html) - 线程队列调配

## 3、如何选择操作符？

[https://beeth0ven.github.io/RxSwift-Chinese-Documentation/content/decision_tree.html](https://beeth0ven.github.io/RxSwift-Chinese-Documentation/content/decision_tree.html)

# 4、RxSwift 生态系统

- [RxDataSources](https://github.com/RxSwiftCommunity/RxDataSources) - UITableView 和 UICollectionView 数据源
- [RxGesture](https://github.com/RxSwiftCommunity/RxGesture) - 页面手势
- [RxMKMapView](https://github.com/RxSwiftCommunity/RxMKMapView) - 地图
- [RxCoreMotion](https://github.com/RxSwiftCommunity/RxCoreMotion) - 陀螺仪
- [RxAlamofire](https://github.com/RxSwiftCommunity/RxAlamofire) - 网络请求
- [RxCoreData](https://github.com/RxSwiftCommunity/RxCoreData) - CoreData 数据库
- [RxRealm](https://github.com/RxSwiftCommunity/RxRealm) - Realm 数据库
- [RxMediaPicker](https://github.com/RxSwiftCommunity/RxMediaPicker) - 图片选择器
- [Action](https://github.com/RxSwiftCommunity/Action) - 行为
- [RxWebKit](https://github.com/RxSwiftCommunity/RxWebKit) - WebView
- [RxEventHub](https://github.com/RxSwiftCommunity/RxEventHub) - 全局通知
- [RxSwiftExt](https://github.com/RxSwiftCommunity/RxSwiftExt) - 添加一些有用的操作符

## **5、IGListKit 的优点**

1. 不要再次调用performBatchUpdates（_ :, completion :)或reloadData（）  
2. 更好的架构与可重复使用的单元和组件
3. 创建具有多种数据类型的Collections
4. 解耦差分算法
5. 完全单元测试
6. 定制您的模型的差异行为
7. 简单的UICollectionView是其核心
8. 可扩展API
9. 使用Objective-C语言，同时全面支持Swift

## 6、swinject的功能

iOS 依赖注入工具，[https://github.com/Swinject/Swinject](https://github.com/Swinject/Swinject) git链接

## 7、SnapKit的使用、注意事项与疑惑

### 使用SnapKit前，一定要先将子控件添加到父视图中

### leading和left、trailing和right

其实在目前国内App中使用leading与left，trailing与right在正常情况下是等价的，这是因为国内的阅读习惯是从左到右的，不过如果你的App需要在阿拉伯国家上架，他们的布局是从右至左时(比如阿拉伯文) 则会对调。

### 8、SnapKit优先级

SnapKit为我们提供了三个默认的方法，required、high、medium、low，优先级最大数值是1000

自己设置优先级的值，可以通过priority()方法来设置

## 9、swift数据库GRDB框架使用

swift数据库，[https://github.com/groue/GRDB.swift](https://github.com/groue/GRDB.swift) git链接

# 四、内存：

## **1.什么是内存泄漏?什么是内存溢出?**

· 内存泄漏指动态分配内存的对象在使用完后没有被系统回收内存,导致对象始终占有着内存,属于内存管理出错, (例如一个对象或者变量使用完成后没有释放,这个对象一直占用着内存)，一次内存泄露危害可以忽略，但内存泄露堆积后果很严重，无论多少内存,迟早会被占光。

· 当程序在申请内存时，没有足够的内存空间供其使用，出现out of memory;比如申请了一个int,但给它存了long才能存下的数，那就是内存溢出。

## **2. 什么是僵尸对象?什么事**野指针**？****什么是空指针?**

· 已经被销毁的对象(不能再使用的对象),内存已经被回收的对象。一个引用计数器为0对象被释放后就变为了僵尸对象;

· 野指针又叫做'悬挂指针', 野指针出现的原因是因为指针没有赋值,或者指针指向的对象已经释放了, 比如指向僵尸对象;野指针可能会指向一块垃圾内存,给野指针发送消息会导致程序崩溃

· 空指针不同于野指针,他是一个没有指向任何内存的指针,空指针是有效指针,值为nil,NULL,Nil,0等,给空指针发送消息不会报错,不会响应消息;

## **3. OC对象的内存管理机制?**

#### **在iOS中，使用引用计数来管理OC对象的内存**

· 一个新创建的OC对象引用计数默认是1，当引用计数减为0，OC对象就会销毁，释放其占用的内存空间

· 调用retain会让OC对象的引用计数+1，调用release会让OC对象的引用计数-1

内存管理的经验总结

· 当调用alloc、new、copy、mutableCopy方法返回了一个对象，在不需要这个对象时，要调用release或者autorelease来释放它

· 想拥有某个对象，就让它的引用计数+1；不想再拥有某个对象，就让它的引用计数-1

可以通过以下私有函数来查看自动释放池的情况

· extern void _objc_autoreleasePoolPrint(void);

## 4.**内存区域分布**

在iOS开发过程中，为了合理的分配有限的内存空间，将内存区域分为五个区，由低地址向高地址分类分别是：代码区、常量区、全局静态区、堆、栈。

· 代码段 -- 程序编译产生的二进制的数据

· 常量区 -- 存储常量数据，通常程序结束后由系统自动释放

· 全局静态区 -- 全局区又可分为未初始化全局区：.bss段和初始化全局区：data段。全局变量和静态变量的存储是放在一块的，初始化的全局变量和静态变量在一块区域， 未初始化的全局变量和未初始化的静态变量在相邻的另一块区域，在程序结束后有系统释放。

· 堆（heap) -- 程序运行过程中,动态分配的内存

· 栈（stack） -- 存放局部变量，临时变量

## **5.堆区和栈取的区别**

按管理方式分

对于栈来讲，是由系统编译器自动管理，不需要程序员手动管理

对于堆来讲，释放工作由程序员手动管理，不及时回收容易产生内存泄露

按分配方式分

堆是动态分配和回收内存的，没有静态分配的堆

栈有两种分配方式：静态分配和动态分配

静态分配是系统编译器完成的，比如局部变量的分配

动态分配是有alloc函数进行分配的，但是栈的动态分配和堆是不同的，它的动 态分配也由系统编译器进行释放，不需要程序员手动管理

## 6.**block在ARC中和MRC中的用法有什么区别,需要注意什么?**

1. 对于没有引用外部变量的Block，无论在ARC还是非ARC下，类型都是 **NSGlobalBlock**，这种类型的block可以理解成一种全局的block，不 需要考虑作用域问题。同时，对他进行Copy或者Retain操作也是无效的
2. 都需要应注意避免循环引用,ARC 下使用__weak 来解决,MRC下使用__Block 来解决;

## **7. 内存泄漏可能会出现的几种原因？**

· 第一种可能：第三方框架不当使用；

· 第二种可能：block循环引用；

· 第三种可能：delegate循环引用；

· 第四种可能：NSTimer循环引用

· 第五种可能：非OC对象内存处理

· 第六种可能：地图类处理

· 第七种可能：大次数循环内存暴涨

## **8.什么情况使用weak关键字，相比assign有什么不同？**

什么情况使用 weak 关键字？

1.在 ARC 中,在有可能出现循环引用的时候,往往要通过让其中一端使用 weak 来解决,比如: delegate 代理属性

2.自身已经对它进行一次强引用,没有必要再强引用一次,此时也会使用 weak,自定义 IBOutlet 控件属性一般也使用 weak；当然，也可以使用strong。在下文也有论述：《IBOutlet连出来的视图属性为什么可以被设置成weak?》

不同点：

1.weak 此特质表明该属性定义了一种“非拥有关系” (nonowning relationship)。为这种属性设置新值时，设置方法既不保留新值，也不释放旧值。此特质同assign类似， 然而在属性所指的对象遭到摧毁时，属性值也会清空(nil out)。 而 assign 的“设置方法”只会执行针对“纯量类型” (scalar type，例如 CGFloat 或 NSlnteger 等)的简单赋值操作。

2.assign 可以用非 OC 对象,而 weak 必须用于 OC 对象

## **9.内存泄漏可能会出现的几种原因？**

· 第一种可能：第三方框架不当使用；

· 第二种可能：block循环引用；

· 第三种可能：delegate循环引用；

· 第四种可能：NSTimer循环引用

· 第五种可能：非OC对象内存处理

· 第六种可能：地图类处理

· 第七种可能：大次数循环内存暴涨

## 10.weak指针的实现原理

· Runtime维护了一个weak表，用于存储指向某个对象的所有weak指针。weak表其实是一个hash（哈希）表，Key是所指对象的地址，Value是weak指针的地址（这个地址的值是所指对象的地址）数组。

· runtime对注册的类， 会进行布局，对于weak对象会放入一个hash表中。 用weak指向的对象内存地址作为key，当此对象的引用计数为0的时候会dealloc，假如weak指向的对象内存地址是a，那么就会以a为键， 在这个weak表中搜索，找到所有以a为键的weak对象，从而设置为nil。

## **11.循环引用**

### **1. 概述**

iOS内存中的分区有：堆、栈、静态区。其中，栈和静态区是操作系统自己管理回收，不会造成循环引用。在堆中的相互引用无法回收，有可能造成循环引用。

循环引用的实质：多个对象相互之间有强引用，不能施放让系统回收。

解决循环引用一般是将 strong 引用改为 weak 引用。

### **2. 循环引用场景分析及解决方法**

#### **1）父类与子类**

如：在使用UITableView 的时候，将 UITableView 给 Cell 使用，cell 中的 strong 引用会造成循环引用。

// controller- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

TestTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"UITableViewCellId" forIndexPath:indexPath];

cell.tableView = tableView;

return cell;}

// cell@interface TestTableViewCell : UITableViewCell@property (nonatomic, strong) UITableView *tableView; // strong 造成循环引用@end

解决：strong 改为 weak

// cell@interface TestTableViewCell : UITableViewCell@property (nonatomic, weak) UITableView *tableView; // strong 改为 weak@end

#### **2）block**

block在copy时都会对block内部用到的对象进行强引用的。

self.testObject.testCircleBlock = ^{

[self doSomething];};

self将block作为自己的属性变量，而在block的方法体里面又引用了 self 本身，此时就很简单的形成了一个循环引用。

应该将 self 改为弱引用

__weak typeof(self) weakSelf = self;

self.testObject.testCircleBlock = ^{

__strong typeof (weakSelf) strongSelf = weakSelf;

[strongSelf doSomething];};

在 ARC 中，在被拷贝的 block 中无论是直接引用 self 还是通过引用 self 的成员变量间接引用 self，该 block 都会 retain self。

· **快速定义宏**

// weak obj

/#define WEAK_OBJ(type) __weak typeof(type) weak##type = type;

// strong obj

/#define STRONG_OBJ(type) __strong typeof(type) str##type = weak##type;

#### **3）Delegate**

delegate 属性的声明如下：

@property (nonatomic, weak) id <TestDelegate> delegate;

如果将 weak 改为 strong，则会造成循环引用

// self -> AViewController

BViewController *bVc = [BViewController new];

bVc = self; [self.navigationController pushViewController: bVc animated:YES];

// 假如是 strong 的情况

// bVc.delegate ===> AViewController (也就是 A 的引用计数 + 1)

// AViewController 本身又是引用了 <BViewControllerDelegate> ===> delegate 引用计数 + 1

// 导致： AViewController <======> Delegate ，也就循环引用啦

#### **4）NSTimer**

NSTimer 的 target 对传入的参数都是强引用（即使是 weak 对象）

解决办法: 《Effective Objective-C 》中的52条方法

#import <Foundation/Foundation.h>

@interface NSTimer (YPQBlocksSupport)

- (NSTimer *)ypq_scheduledTimeWithTimeInterval:(NSTimeInterval)interval
	block:(void(^)())block
	repeats:(BOOL)repeats;

@end

#import "NSTimer+YPQBlocksSupport.h"

@implementation NSTimer (YPQBlocksSupport)

- (NSTimer *)ypq_scheduledTimeWithTimeInterval:(NSTimeInterval)interval
	block:(void(^)())block
	repeats:(BOOL)repeats{
	return [self scheduledTimerWithTimeInterval:interval
	target:self
	selector:@selector(ypq_blockInvoke:) userInfo:[block copy]
	repeats:repeats];}
- (void)ypq_blockInvoke:(NSTimer *)timer{
	void (^block)() = timer.userInfo;
	if(block)
	{
	block();
	}}

@end

使用方式：

__weak ViewController * weakSelf = self;[NSTimer ypq_scheduledTimeWithTimeInterval:4.0f

block:^{

ViewController * strongSelf = weakSelf;

[strongSelf afterThreeSecondBeginAction];

}

repeats:YES];

计时器保留其目标对象，反复执行任务导致的循环，确实要注意，另外在dealloc的时候，不要忘了调用计时器中的 invalidate方法。

## **12.Swift**循环引用解决方法**?**

1. 转换为值类型, 只有类会存在引用循环, 所以如果能不用类, 是可以解引用循环的,
2. delegate 使用 weak 属性.
3. 闭包中, 对有可能发生循环引用的对象, 使用 weak 或者 unowned, 修饰

# 五、数据结构

## 1、Q: 数组和链表的区别  

A: 链表是链式的存储结构;数组是顺序的存储结构。 链表通过指针来连接元素与元素,数组则是把所有元素按次序依次存储。  

## 2、Q: 数组和链表的优缺点  

A: 链表的插入删除元素相对数组较为简单,不需要移动元素,且较为容易实现长度扩充,但是寻找某个元素较为困难; 数组寻找某个元素较为简单,但插入与删除比较复杂,由于最大长度需要再编程一开始时指定,故当达到最大长度时,扩充长度不如链表方便。  

## 3、Q: 双向链表和单向链表的区别  

A: 双向链表的每个数据结点中都有两个指针，分别指向直接后继和直接前驱。所以，从双向链表中的任意一个结点开始，都可以很方便地访问它的前驱结点和后继结点。  

## 4、Q: 单向链表反转的几种算法  

A: 三指针法:三个指针记录修改节点，一步步往前反转。递归法：通过校验后节点非空条件递归，实现从后到前操作链表。  

## 5Q: 单向链表两两反转算法  

A: 思路，在三指针算法基础上加一个指针记录上一组反转后的后元素。







[新页面](%E6%96%B0%E9%A1%B5%E9%9D%A2/%E6%96%B0%E9%A1%B5%E9%9D%A2.md)

