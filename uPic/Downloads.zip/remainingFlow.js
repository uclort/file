const request = require('request');

request('https://api.duang.cloud/quantumultx_subscribe/9480/FPGfur2llB2m', { json: true }, (err, res, body) => {
  if (err) { return console.log(err); }
  let bodyGroup = `${body}`
  let remainingFlow = bodyGroup.split('\n')[0]
  remainingFlow = remainingFlow.split(',')
  remainingFlow = remainingFlow[remainingFlow.length - 1]
  remainingFlow = remainingFlow.replace(/tag=剩余流量:/g, '')
  remainingFlow = remainingFlow.replace(/\s+/g, '')
  sendTrafficNotification(remainingFlow)
});

function sendTrafficNotification(remainingFlow) {
  let url = encodeURI(`https://api.day.app/g8UVEChxu6w2e7UgbDo65b/DuangCloud 流量提醒/您的剩余流量为：${remainingFlow}（每月 29 号重置）`)
  console.log(url)
  request(url, { json: true }, (err, res, body) => {
    if (err) { return console.log(err); }

  });
}
