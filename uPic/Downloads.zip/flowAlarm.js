const fs = require('fs');
var moment = require('moment');
const request = require('request');
const path = './flow/flow.txt'

let title = ''
let content = ''

const writeFileRecursive = function (path, buffer, callback) {
  let lastPath = path.substring(0, path.lastIndexOf("/"));
  fs.mkdir(lastPath, { recursive: true }, (err) => {
    if (err) return callback(err);
    fs.writeFile(path, buffer, function (err) {
      if (err) return callback(err);
      return callback(null);
    });
  });
}


request('https://api.duang.cloud/quantumultx_subscribe/9480/FPGfur2llB2m', { json: true }, (err, res, body) => {
  if (err) { return console.log(err); }
  let bodyGroup = `${body}`
  let remainingFlow = bodyGroup.split('\n')[0]
  remainingFlow = remainingFlow.split(',')
  remainingFlow = remainingFlow[remainingFlow.length - 1]
  remainingFlow = remainingFlow.replace(/[^\d]/g, '')
  if (remainingFlow == '') {
    let fileName = moment().format('YYYY-MM-DD-HH-mm-ss')
    let errorPath = `./flow/error/${fileName}.txt`
    writeFileRecursive(errorPath, bodyGroup, (err) => {
      if (err) console.error(err);
      console.info("错误信息已写入");
    })
    return
  }
  fs.readFile(path, { encoding: "utf-8" }, function (err, fr) {
    let oldFlow = ''
    if (err) { } else {
      oldFlow = fr
    }
    updateOldFlow(remainingFlow)
    if (((remainingFlow - oldFlow) > 0) && (oldFlow != '')) { // 流量已重置
      title = 'DuangCloud 流量重置'
      content = `您的流量已经重置，剩余流量：${remainingFlow}G`
    } else if (remainingFlow > 10 && (oldFlow - remainingFlow > 10)) {
      title = 'DuangCloud 流量警告'
      content = `10 分钟内您使用了 ${oldFlow - remainingFlow}G 流量，请注意使用情况`
    } else if (((remainingFlow <= 10) && remainingFlow > 0) && remainingFlow != oldFlow) {
      title = 'DuangCloud 流量警告'
      content = `您的流量已经不足 ${remainingFlow}G，请注意使用情况`
    } else if (remainingFlow == 0 && oldFlow != 0) {
      title = 'DuangCloud 流量用尽'
      content = `您的流量已用尽，请等待 29 号 0 点重置`
    }
    sendTrafficNotification()
  })
})

function sendTrafficNotification() {
  if (title == '' || content == '') {
    return
  }
  let url = encodeURI(`https://api.day.app/g8UVEChxu6w2e7UgbDo65b/${title}/${content}`)
  console.log(url)
  request(url, { json: true }, (err, res, body) => {
    if (err) { return console.log(err); }
  });
}

function updateOldFlow(flow) {
  if (flow < 0) {
    flow = 0
  }
  writeFileRecursive(path, flow, (err) => {
    if (err) console.error(err);
    console.info("剩余流量已写入");
  })
}
