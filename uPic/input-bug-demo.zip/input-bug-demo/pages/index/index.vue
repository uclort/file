<template>
	<view class="content">
		<input class="input" :password="isPassword" :placeholder="isPassword ? '我是密码框' : '我是文本框'" />
		<button class="button" type="default" @click="changeInputType">修改输入框类型</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isPassword: true,
			}
		},
		onLoad() {

		},
		methods: {
			changeInputType() {
				this.isPassword = !this.isPassword
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column-reverse;
		height: 100vh;
	}

	.button {
		margin: 10px;
	}

	.input {
		border: 1px solid red;
		margin: 10px;
	}
</style>
